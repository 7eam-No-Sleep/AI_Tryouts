import mysql from 'mysql2/promise';
//import fs = require 'fs'
